// App.js


// App.js
import React, { useState } from 'react';
import './App.css';
import Login from './Login';
import ExpenseTracker from './ExpenseTracker';

function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  const handleLogin = (credentials) => {
    // Perform authentication logic here
    // For demo purposes, let's consider any non-empty credentials as a successful login
    if (credentials.username.trim() !== '' && credentials.password.trim() !== '') {
      setLoggedIn(true);
    } else {
      alert('Invalid username or password');
    }
  };



  return (
    <div className="App">
      {loggedIn ? (
        <>
          
          <ExpenseTracker />
        </>
      ) : (
        <Login onLogin={handleLogin} />
      )}
    </div>
  );
}

export default App;